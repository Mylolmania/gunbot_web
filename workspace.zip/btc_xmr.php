<?php
require('assets/php/header.php');
?>

<?php
require('assets/php/footer.php');
?>