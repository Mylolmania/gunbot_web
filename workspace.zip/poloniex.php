<?php
include($_SERVER["DOCUMENT_ROOT"]."/assets/php/header.php");?>

<?php
include($_SERVER["DOCUMENT_ROOT"]."/assets/php/footer.php");?>
?>