var config = {

	COINS_PAIR:   'BTC_ETC',
	KEY: '',
	SECRET: '',
	SMTP: false,
	SMTP_EMAIL: '*********@gmail.com',
	SMTP_PASSWORD: '********',
	SMTP_PROTOCOL: 'SMTPS',
	SMTP_HOST: 'smtp.gmail.com',






	// margin to sell when currency increases its value (example: sell when currency increases 2.5% of paid value)
	GAIN: 1, 

 	// max amount of BTC balance to use for each pair	
	MAX_BALANCE: 0.01,

	// sell all balance if currency decreases x% after you bought it
	SECURITY_MARGIN: 60, 

	 // time, in seconds, to verify margin price again if price freezes
	TIME_DELAY_PRICE: 120,

	 // minimum volume to be a good currency to trade (used in daily recommendations)
	MINIMUM_VOLUME_GOOD_CURRENCY: 500,

	 // minimum variation between low and high price to suggest to trade
	MINIMUM_VARIATION_SUGGEST_TRADE: 5,

	// weighted average interval in hours
	STARTEMA1: 0.2,

	// weighted average interval in hours
	STARTEMA2: 0.4,

	PERIOD: 15,
	BLOODY_MARY_ENABLED: 0,


	 // btc balance for test purposes,
	BTC_BALANCE: 2,

	 // max altcoin we have
	MAX_ALTCOINS_BALANCE: 0.01,

	// bot cycle delay (koef*sec)
	BOT_SLEEP_DELAY:(1000)*120,

	// overall bot lifetime(koef*min),
	BOT_MAX_LIFETIME:999999999,

	I_REALLY_WANT_IT:true,

	HACK_SELL_ALL:true,
	  
	  // must be  1 > x > 0
	BUY_SMALL_PORTION:1,

	
	 // limit of latest prices to analyze to determine if price is growing or falling
	MAX_LATEST_PRICES: 100,

	// limit of latest prices to show in console.log
	MAX_LATEST_PRICES_SHOWN: 10, 

	SHOW_LASTEST_DIRECTIONS:true,

	MAX_LATEST_DIRECTIONS:30,

	MAX_LATEST_DIRECTIONS_SHOWN:10,

	LASTEST_DIRECTIONS_LIST_WIDTH:15,

	SAVEFILE: '-save.json',

	SELL_ON_START:true
};
 
module.exports = config;
