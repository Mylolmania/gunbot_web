var config = {
	//-----------------------------------------------
	//  PRIMARY SETTINGS
	//-----------------------------------------------
	KEY: '',
	SECRET: '',
	BUYLVL1: 1, // first level margin to buy when currency decreases its value (example: buy when currency decreases 1% of EMA)
	BUYLVL2: 3, // second level margin to buy when currency decreases its value (example: buy when currency decreases 3% of EMA)
	BUYLVL3: 5, // third level margin to buy when currency decreases its value (example: buy when currency decreases 5% of EMA)
	SELLLVL1: 2, // first level margin to sell when currency increases its value (example: sell when currency increases 2% of paid)
	SELLLVL2: 5, // second level margin to sell when currency increases its value (example: sell when currency increases 5% of paid)
	SELLLVL3: 10, // third level margin to sell when currency increases its value (example: sell when currency increases 10% of paid)
	BUYLVL: 3, // buy level you want your gunbot to reach (example: i want my gunbot to buy when price reaches level 3)
	SELLLVL: 3, // sell level you want your gunbot to reach (example: i want my gunbot to sell when price reaches level 3)
	BTC_TRADING_LIMIT: 0.02,// max amount of BTC balance to use for each pair	
	SECURITY_MARGIN: 60, // sell all balance if currency decreases x% after you bought it
	SELL_ON_START:false,	
	CANCEL_SELL_ORDERS_ON_START:false,

	MAX_LATEST_PRICES: 30,// limit of latest prices to analyze to determine if price is growing or falling
	MAX_LATEST_DIRECTIONS:30,// limit of latest  price directions ,used in supergun detection
  
	STARTEMA1: 0.02,// weighted average interval in hours
	STARTEMA2: 0.04,// weighted average interval in hours
	PERIOD: 15,   // candlestick period
	
	SAVEFILE_SUFFIX: '-save.json', 
 
 
	//-----------------------------------------------
	//   BOT TIMINGS
	//-----------------------------------------------
	BOT_SLEEP_DELAY:(1000)*13,// bot cycle delay (koef*sec)
	BOT_MAX_LIFETIME:999999999,// overall bot lifetime(koef*min),
	BOT_ON_FAIL_DELAY:(1000)*3, // bot repeat cycle delay if previous cycle failed  (koef*sec)
	//-----------------------------------------------
	// EMAIL
	//-----------------------------------------------
	ALERT_ON_NO_FUNDS:false,  // email on insufficcient funds
	SMTP_EMAIL: '%40@gmail.com',
	ALERT_EMAIL:'********',
	SMTP_PASSWORD: '**********',
	SMTP: true,
	SMTP_PROTOCOL: 'SMTPS',
	SMTP_HOST: 'smtp.gmail.com',


	//-----------------------------------------------
	//  DEBUG
	//-----------------------------------------------
	DEBUG_LOG:false, 
	I_REALLY_WANT_IT:false,// debug hardcode hack
	BUY_SMALL_PORTION:1,// debug volume limiter,must be  1 > x > 0

	//-----------------------------------------------
	//  OUTPUT 
	//-----------------------------------------------
	MAX_LATEST_PRICES_SHOWN: 0, // limit of latest prices to show in console.log
	SHOW_LASTEST_DIRECTIONS:false,  // show chart in console
	MAX_LATEST_DIRECTIONS_SHOWN:0, // chart height
	LASTEST_DIRECTIONS_LIST_WIDTH:0, // chart width

	//-----------------------------------------------
	//   OTHER (might be deprecated/not in use)
	//-----------------------------------------------
	BTC_BALANCE: 2// btc balance for test purposes,
};
 
module.exports = config;
